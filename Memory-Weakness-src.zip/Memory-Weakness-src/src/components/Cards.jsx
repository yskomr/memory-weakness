import React from 'react';
import cardBack from '../img/bk0.png';
import dummy from '../img/bk0.png'
import c1 from '../img/c01.png';
import c2 from '../img/c02.png';
import c3 from '../img/c03.png';
import c4 from '../img/c04.png';
import c5 from '../img/c05.png';
import c6 from '../img/c06.png';
import c7 from '../img/c07.png';
import c8 from '../img/c08.png';
import c9 from '../img/c09.png';
import c10 from '../img/c10.png';
import c11 from '../img/c11.png';
import c12 from '../img/c12.png';
import c13 from '../img/c13.png';
import d1 from '../img/d01.png';
import d2 from '../img/d02.png';
import d3 from '../img/d03.png';
import d4 from '../img/d04.png';
import d5 from '../img/d05.png';
import d6 from '../img/d06.png';
import d7 from '../img/d07.png';
import d8 from '../img/d08.png';
import d9 from '../img/d09.png';
import d10 from '../img/d10.png';
import d11 from '../img/d11.png';
import d12 from '../img/d12.png';
import d13 from '../img/d13.png';
import h1 from '../img/h01.png';
import h2 from '../img/h02.png';
import h3 from '../img/h03.png';
import h4 from '../img/h04.png';
import h5 from '../img/h05.png';
import h6 from '../img/h06.png';
import h7 from '../img/h07.png';
import h8 from '../img/h08.png';
import h9 from '../img/h09.png';
import h10 from '../img/h10.png';
import h11 from '../img/h11.png';
import h12 from '../img/h12.png';
import h13 from '../img/h13.png';
import s1 from '../img/s01.png';
import s2 from '../img/s02.png';
import s3 from '../img/s03.png';
import s4 from '../img/s04.png';
import s5 from '../img/s05.png';
import s6 from '../img/s06.png';
import s7 from '../img/s07.png';
import s8 from '../img/s08.png';
import s9 from '../img/s09.png';
import s10 from '../img/s10.png';
import s11 from '../img/s11.png';
import s12 from '../img/s12.png';
import s13 from '../img/s13.png';


class Cards extends React.Component {

    render() {

        return (
            <div className='cards'>
                <img className='cards-img' src={this.props.cardImg} alt='' />

            </div>
        )
    }
}

export default Cards;
export { cardBack, dummy };
export const cardList = [
    { cardNum: 1, cardImg: c1, isSelected: false, isMatched: false },
    { cardNum: 2, cardImg: c2, isSelected: false, isMatched: false },
    { cardNum: 3, cardImg: c3, isSelected: false, isMatched: false },
    { cardNum: 4, cardImg: c4, isSelected: false, isMatched: false },
    { cardNum: 5, cardImg: c5, isSelected: false, isMatched: false },
    { cardNum: 6, cardImg: c6, isSelected: false, isMatched: false },
    { cardNum: 7, cardImg: c7, isSelected: false, isMatched: false },
    { cardNum: 8, cardImg: c8, isSelected: false, isMatched: false },
    { cardNum: 9, cardImg: c9, isSelected: false, isMatched: false },
    { cardNum: 10, cardImg: c10, isSelected: false, isMatched: false },
    { cardNum: 11, cardImg: c11, isSelected: false, isMatched: false },
    { cardNum: 12, cardImg: c12, isSelected: false, isMatched: false },
    { cardNum: 13, cardImg: c13, isSelected: false, isMatched: false },
    { cardNum: 1, cardImg: d1, isSelected: false, isMatched: false },
    { cardNum: 2, cardImg: d2, isSelected: false, isMatched: false },
    { cardNum: 3, cardImg: d3, isSelected: false, isMatched: false },
    { cardNum: 4, cardImg: d4, isSelected: false, isMatched: false },
    { cardNum: 5, cardImg: d5, isSelected: false, isMatched: false },
    { cardNum: 6, cardImg: d6, isSelected: false, isMatched: false },
    { cardNum: 7, cardImg: d7, isSelected: false, isMatched: false },
    { cardNum: 8, cardImg: d8, isSelected: false, isMatched: false },
    { cardNum: 9, cardImg: d9, isSelected: false, isMatched: false },
    { cardNum: 10, cardImg: d10, isSelected: false, isMatched: false },
    { cardNum: 11, cardImg: d11, isSelected: false, isMatched: false },
    { cardNum: 12, cardImg: d12, isSelected: false, isMatched: false },
    { cardNum: 13, cardImg: d13, isSelected: false, isMatched: false },
    { cardNum: 1, cardImg: h1, isSelected: false, isMatched: false },
    { cardNum: 2, cardImg: h2, isSelected: false, isMatched: false },
    { cardNum: 3, cardImg: h3, isSelected: false, isMatched: false },
    { cardNum: 4, cardImg: h4, isSelected: false, isMatched: false },
    { cardNum: 5, cardImg: h5, isSelected: false, isMatched: false },
    { cardNum: 6, cardImg: h6, isSelected: false, isMatched: false },
    { cardNum: 7, cardImg: h7, isSelected: false, isMatched: false },
    { cardNum: 8, cardImg: h8, isSelected: false, isMatched: false },
    { cardNum: 9, cardImg: h9, isSelected: false, isMatched: false },
    { cardNum: 10, cardImg: h10, isSelected: false, isMatched: false },
    { cardNum: 11, cardImg: h11, isSelected: false, isMatched: false },
    { cardNum: 12, cardImg: h12, isSelected: false, isMatched: false },
    { cardNum: 13, cardImg: h13, isSelected: false, isMatched: false },
    { cardNum: 1, cardImg: s1, isSelected: false, isMatched: false },
    { cardNum: 2, cardImg: s2, isSelected: false, isMatched: false },
    { cardNum: 3, cardImg: s3, isSelected: false, isMatched: false },
    { cardNum: 4, cardImg: s4, isSelected: false, isMatched: false },
    { cardNum: 5, cardImg: s5, isSelected: false, isMatched: false },
    { cardNum: 6, cardImg: s6, isSelected: false, isMatched: false },
    { cardNum: 7, cardImg: s7, isSelected: false, isMatched: false },
    { cardNum: 8, cardImg: s8, isSelected: false, isMatched: false },
    { cardNum: 9, cardImg: s9, isSelected: false, isMatched: false },
    { cardNum: 10, cardImg: s10, isSelected: false, isMatched: false },
    { cardNum: 11, cardImg: s11, isSelected: false, isMatched: false },
    { cardNum: 12, cardImg: s12, isSelected: false, isMatched: false },
    { cardNum: 13, cardImg: s13, isSelected: false, isMatched: false }
];

