import React, { Component, useState, useEffect } from 'react';
import Cards from './Cards';

import { cardBack, cardList } from './Cards';


//let isSecondClicked = false
const Main = () => {
    const [isFirstClicked, setIsFirstClicked] = useState(false)
    const [isSecondClicked, setIsSecondClicked] = useState(false)
    const [firstCardNum, setFirstCardNum] = useState(0)
    const [secondCardNum, setSecondCardNum] = useState(100)
    const [startFlg, setStartFlg] = useState(false)
    const [newCardList, setNewCardList] = useState(cardList)


    useEffect(() => {
        cardSuffle(cardList)
    }, [])

    let timer
    useEffect(() => {
        sleep(1000)
        //タイマー
        timer = setTimeout(judgeCards(), 1000)

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isSecondClicked])



    //シャッフル
    const cardSuffle = (cardList) => {
        for (let i = cardList.length - 1; i >= 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [cardList[i], cardList[j]] = [cardList[j], cardList[i]];
        }
    }

    //クリック時動作
    const cardClick = (cardItem) => {
        if (isFirstClicked === false) {
            console.log('1枚目')
            cardItem.isSelected = true;

            //1回目のクリックフラグをTrueにし、stateにcardNumを格納
            setIsFirstClicked(isFirstClicked => true)
            setFirstCardNum(firstCardNum => cardItem.cardNum)
        } else if (isSecondClicked === false) {
            console.log('2枚目')
            cardItem.isSelected = true;

            //2回目のクリックフラグをTrueにし、stateにcardNumを格納
            setSecondCardNum(secondCardNum => cardItem.cardNum)
            setIsSecondClicked(isSecondClicked => true)
            //isSecondClicked = true

            //timer = setTimeout(judgeCards(), 1000)


        } else {

            //3回目以降は何もしない
        }
    }

    //判定用メソッド
    const judgeCards = () => {

        if (isSecondClicked === false) { return }

        setIsFirstClicked(isFirstClicked => false)
        setIsSecondClicked(isSecondClicked => false)
        //isSecondClicked = false
        setFirstCardNum(firstCardNum => 0)
        setSecondCardNum(secondCardNum => 100)
        cardList.map((cardItem) => {
            cardItem.isSelected = false
            return cardItem
        })

        if (firstCardNum === secondCardNum) {

            cardList.map((cardItem) => {
                if (cardItem.isSelected) {
                    cardItem.isMatched = true
                    return cardItem
                }

            })

        }



        clearTimeout(timer);
    }

    //指定時間(ミリ秒)待機させる
    const sleep = (waitMsec) => {
        var startMsec = new Date();
        while (new Date() - startMsec < waitMsec);
    }

    return (
        < div className='main-container' >
            <button onClick={() => { setStartFlg(startFlg => true) }}>START</button>
            <div className={startFlg ? 'cards-container' : 'none'}>
                {newCardList.map((cardItem) => {
                    return (
                        //<span onClick={() => { cardClick(cardItem) }}>
                        //<Cards
                        //cardImg={cardItem.isSelected ? cardItem.cardImg : cardBack}
                        ///>
                        //</span>
                        < img
                            className={cardItem.isMatched ? 'none' : 'cards-img'}
                            src={cardItem.isSelected ? cardItem.cardImg : cardBack}
                            alt=''
                            onClick={() => { cardClick(cardItem) }}
                        />
                    )
                })}
            </div>
        </div >
    )

}
export default Main;
