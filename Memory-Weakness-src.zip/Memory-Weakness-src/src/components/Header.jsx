import React from 'react';

class Header extends React.Component {
    render() {
        return (
            <div className='header-container'>
                <h1>神経衰弱</h1>
            </div>
        );
    }
}

export default Header;